import asyncio
import aiohttp
import sys
import logging
from typing import List, Optional, Dict, Tuple, Set

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Configuration: URLs for Proxy Lists ---
# Add multiple URLs per type. The script will fetch from all of them.
PROXY_SOURCES: Dict[str, List[str]] = {
    "http": [
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
        "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt",
        "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-https.txt", # Adding HTTPS specific list here too
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt",
        "https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/http.txt",
        "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
        "https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt",
    ],
    "socks4": [
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt",
        "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks4.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks4.txt",
        "https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/socks4.txt",
        "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks4.txt",
    ],
    "socks5": [
        "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt",
        "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt",
        "https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt",
        "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/socks5.txt",
        "https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt", # Specific SOCKS5 source
        "https://raw.githubusercontent.com/UptimerBot/proxy-list/main/proxies/socks5.txt",
        "https://raw.githubusercontent.com/mmpx12/proxy-list/master/socks5.txt",
    ],
}
# --- End Configuration ---

async def fetch_proxy_list(session: aiohttp.ClientSession, url: str) -> List[str]:
    """Fetches a proxy list from a single given URL."""
    # Reduced logging noise for individual fetches when using multiple sources
    # logging.info(f"Attempting fetch from: {url}")
    try:
        async with session.get(url, timeout=20) as response: # Slightly shorter timeout per source
            response.raise_for_status()
            text = await response.text()
            proxies = [line.strip() for line in text.splitlines() if line.strip() and ':' in line] # Basic validation: must contain a colon
            # logging.debug(f"Fetched {len(proxies)} proxies from {url}")
            return proxies
    except aiohttp.ClientError as e:
        logging.warning(f"Network error fetching {url}: {e}")
    except asyncio.TimeoutError:
        logging.warning(f"Timeout fetching {url}")
    except Exception as e:
        logging.warning(f"Error fetching {url}: {e}")
    return []

def get_user_choices() -> Tuple[str, Optional[str], Optional[int]]:
    """Presents an interactive menu to the user and gets their choices."""
    print("--- ReProx Menu ---")

    # 1. Choose Proxy Type
    print("\nSelect Proxy Type:")
    available_types = list(PROXY_SOURCES.keys())
    for i, p_type in enumerate(available_types):
        print(f"  {i+1}. {p_type.upper()} (fetches from {len(PROXY_SOURCES[p_type])} sources)")

    while True:
        try:
            choice = input(f"Enter choice (1-{len(available_types)}): ")
            choice_index = int(choice) - 1
            if 0 <= choice_index < len(available_types):
                proxy_type = available_types[choice_index]
                break
            else:
                print("Invalid choice number. Please try again.")
        except ValueError:
            print("Invalid input. Please enter a number.")

    # 2. Choose Output File
    output_file: Optional[str] = None
    while True:
        save_choice = input("\nSave proxies to a file? (y/n): ").lower().strip()
        if save_choice == 'y':
            output_file = input("Enter filename (e.g., proxies.txt): ").strip()
            if not output_file:
                print("Filename cannot be empty. Please try again.")
                continue
            break
        elif save_choice == 'n':
            break
        else:
            print("Invalid input. Please enter 'y' or 'n'.")

    # 3. Choose Limit
    limit: Optional[int] = None
    while True:
        limit_choice = input("\nLimit the number of proxies? (y/n): ").lower().strip()
        if limit_choice == 'y':
            while True:
                try:
                    limit_str = input("Enter the maximum number of proxies: ").strip()
                    limit = int(limit_str)
                    if limit <= 0:
                        print("Limit must be a positive number.")
                    else:
                        break
                except ValueError:
                    print("Invalid input. Please enter a whole number.")
            break
        elif limit_choice == 'n':
            break
        else:
            print("Invalid input. Please enter 'y' or 'n'.")

    print("\n--------------------------")
    return proxy_type, output_file, limit

async def main():
    """Main function to get choices via menu and fetch proxies from multiple sources."""
    try:
        proxy_type, output_file, limit = get_user_choices()
    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
        sys.exit(0)

    logging.info(f"Selected proxy type: {proxy_type}")
    if output_file:
        logging.info(f"Output file: {output_file}")
    if limit is not None:
        logging.info(f"Proxy limit: {limit}")

    urls_to_fetch = PROXY_SOURCES[proxy_type]
    logging.info(f"Fetching from {len(urls_to_fetch)} sources for {proxy_type.upper()} proxies...")

    all_proxies: Set[str] = set() # Use a set for automatic deduplication

    async with aiohttp.ClientSession() as session:
        # Create tasks for all fetch operations
        tasks = [fetch_proxy_list(session, url) for url in urls_to_fetch]
        # Run tasks concurrently and gather results
        results = await asyncio.gather(*tasks)

        # Process results
        fetched_count = 0
        for proxy_list in results:
            if proxy_list: # If fetch was successful and returned proxies
                fetched_count += len(proxy_list)
                all_proxies.update(proxy_list) # Add proxies to the set

    if not all_proxies:
        logging.warning("No proxies were fetched from any source. Check source URLs or network connection.")
        sys.exit(1)

    # Convert set back to list for consistent ordering (optional, but good practice)
    # Note: set order is not guaranteed, but list conversion makes slicing predictable
    unique_proxies = list(all_proxies)

    logging.info(f"Fetched {fetched_count} proxies in total, {len(unique_proxies)} unique proxies found.")

    # Apply limit if specified
    if limit is not None:
        unique_proxies = unique_proxies[:limit]
        logging.info(f"Limiting output to {len(unique_proxies)} proxies.")

    # Output results
    if output_file:
        try:
            with open(output_file, 'w') as f:
                for proxy in unique_proxies:
                    f.write(proxy + '\n')
            logging.info(f"Successfully saved {len(unique_proxies)} proxies to {output_file}")
            print(f"\nProxies saved to {output_file}")
        except IOError as e:
            logging.error(f"Error writing to output file {output_file}: {e}")
            print(f"\nError saving to file. Printing proxies to console instead:")
            print(f"\n--- ReProx - Scraped {proxy_type.upper()} Proxies ({len(unique_proxies)}) ---")
            for proxy in unique_proxies:
                print(proxy)
            print("---------------------------")
    else:
        print(f"\n--- ReProx - Scraped {proxy_type.upper()} Proxies ({len(unique_proxies)}) ---")
        for proxy in unique_proxies:
            print(proxy)
        print("---------------------------")

    print("\nReminder: Free proxies are often unreliable and pose security risks.")
    print("Use them with caution and never for sensitive activities.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except RuntimeError as e:
        if "Cannot run the event loop while another loop is running" in str(e):
             logging.error("Asyncio loop already running. This script might need adjustments for your environment (e.g., Jupyter).")
        else:
            logging.error(f"Runtime error running asyncio: {e}")
        sys.exit(1)
    except KeyboardInterrupt:
        logging.info("\nScraping interrupted by user.")
        sys.exit(0)

